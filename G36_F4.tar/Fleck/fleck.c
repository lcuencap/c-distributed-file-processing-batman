#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <ctype.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <stdio.h>
#include "../Utils/file_utils.h"
#include "../Utils/sys_params.h"
#include "../Utils/trames.h"

#define BUF_INICIAL 256
#define TIMEOUT_SECONDS 5 // Temps límit per rebre respostes
#define MAX_RETRIES 3     // Nombre màxim de retries per connectar a Gotham o un worker

int connected_to_gotham = 0;  // Indica si Fleck està connectat a Gotham
int sock_fd = -1;             // Descriptor del socket connectat a Gotham
int worker_fd = -1;           // Descriptor del socket connectat a un worker

/**
 * Connecta amb un servidor (ja sigui Gotham o un worker) usant sockets TCP.
 * @param ip L'adreça IP del servidor.
 * @param port El port del servidor.
 * @return Descriptor del socket connectat, o -1 si hi ha un error.
 */
int connectar_a_server(const char *ip, int port) {
    int retries = 0;
    char buffer[256];

    while (retries < MAX_RETRIES) {
        // Mostra informació de l'intent
        int len = snprintf(buffer, sizeof(buffer), "Intentant connectar a %s:%d (Intent %d/%d)\n", ip, port, retries + 1, MAX_RETRIES);
        write(STDOUT_FILENO, buffer, len);

        // Crear socket
        int sock_fd = socket(AF_INET, SOCK_STREAM, 0);
        if (sock_fd < 0) {
            len = snprintf(buffer, sizeof(buffer), "Error creant el socket\n");
            write(STDERR_FILENO, buffer, len);
            return -1;
        }

        // Configurar l'adreça del servidor
        struct sockaddr_in server_addr;
        memset(&server_addr, 0, sizeof(server_addr));
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(port);

        if (inet_pton(AF_INET, ip, &server_addr.sin_addr) <= 0) {
            len = snprintf(buffer, sizeof(buffer), "Error convertint l'adreça IP: %s\n", ip);
            write(STDERR_FILENO, buffer, len);
            close(sock_fd);
            return -1;
        }

        // Intentar connectar al servidor
        if (connect(sock_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
            retries++;
            len = snprintf(buffer, sizeof(buffer), "Error connectant a %s:%d, reintentant\n", ip, port);
            write(STDERR_FILENO, buffer, len);
            close(sock_fd);
            sleep(1); // Esperar abans de reintentar
            continue;
        }

        // Configurar timeout per al socket
        struct timeval timeout;
        timeout.tv_sec = TIMEOUT_SECONDS;
        timeout.tv_usec = 0;
        setsockopt(sock_fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));

        // Connexió establerta
        len = snprintf(buffer, sizeof(buffer), "Connexió establerta amb %s:%d\n", ip, port);
        write(STDOUT_FILENO, buffer, len);

        return sock_fd;
    }

    // Si no s'ha pogut connectar després de reintents
    int len = snprintf(buffer, sizeof(buffer), "No s'ha pogut connectar a %s:%d després de %d intents\n", ip, port, MAX_RETRIES);
    write(STDERR_FILENO, buffer, len);

    return -1;
}


/**
 * Gestió de la senyal Ctrl+C per tancar correctament Fleck.
 * Envia una trama de desconnexió a Gotham i al worker (si escau) i allibera recursos.
 * @param sig Senyal rebuda (no utilitzada).
 */
void ctrlc_handler(int sig) {
    (void)sig;
    write(STDOUT_FILENO, "\nTancant Fleck...\n", strlen("\nTancant Fleck...\n"));

    if (connected_to_gotham) {
        // Envia una trama de desconnexió a Gotham
        Trama trama;
        inicialitzar_trama(&trama, 0x07, "");
        write(sock_fd, &trama, sizeof(trama));
        close(sock_fd);
        sock_fd = -1;
        connected_to_gotham = 0;
        write(STDOUT_FILENO, "Desconnectat correctament de Gotham.\n", strlen("Desconnectat correctament de Gotham.\n"));
    }

    if (worker_fd >= 0) {
        // Envia una trama de desconnexió al worker
        Trama trama;
        inicialitzar_trama(&trama, 0x07, "");
        write(worker_fd, &trama, sizeof(trama));
        close(worker_fd);
        worker_fd = -1;
        write(STDOUT_FILENO, "Desconnectat correctament del worker.\n", strlen("Desconnectat correctament del worker.\n"));
    }

    write(STDOUT_FILENO, "Fleck finalitzat correctament.\n", strlen("Fleck finalitzat correctament.\n"));
    exit(0);
}

/**
 * Estableix la connexió inicial amb Gotham enviant una trama de tipus 0x01.
 * @param socket_fd Descriptor del socket connectat a Gotham.
 * @param username Nom de l'usuari.
 * @param ip Adreça IP de Gotham.
 * @param port Port de Gotham.
 */
void establir_connexio_gotham(int socket_fd, const char *username, const char *ip, int port) {
    Trama trama;
    char data[365];
    snprintf(data, sizeof(data), "%s&%s&%d", username, ip, port);
    inicialitzar_trama(&trama, 0x01, data);

    write(socket_fd, &trama, sizeof(trama));

    Trama resposta;
    if (read(socket_fd, &resposta, sizeof(resposta)) != sizeof(resposta)) {
        write(STDOUT_FILENO, "Error rebent resposta de Gotham\n", strlen("Error rebent resposta de Gotham\n"));
        return;
    }
    snprintf(data, sizeof(data), "Resposta rebuda: Type=%d, Data_Length=%d, Checksum=%d, Data=%s\n",
         resposta.type, resposta.data_length, resposta.checksum, resposta.data);
    write(STDOUT_FILENO, data, strlen(data));

    if (!validar_trama(&resposta)) {
        write(STDOUT_FILENO, "Resposta de Gotham invalida\n", strlen("Resposta de Gotham invalida\n"));
        return;
    }

    if (resposta.type == 0x01 && resposta.data_length == 0) {
        write(STDOUT_FILENO, "Connexio establerta amb Gotham\n", strlen("Connexio establerta amb Gotham\n"));
    } else if (strcmp(resposta.data, "CON_KO") == 0) {
        write(STDOUT_FILENO, "Connexio rebutjada per Gotham\n", strlen("Connexio rebutjada per Gotham\n"));
    }
}

/**
 * Divideix i delega gestions de comandes en funcions més petites.
 * Gestió de la comanda CONNECT.
 * @param config Configuració de connexió a Gotham.
 * @param username Nom de l'usuari.
 */
void gestionar_comanda_connect(ConfigBase *config, const char *username) {
    sock_fd = connectar_a_server(config->ip, config->port);
    if (sock_fd < 0) {
        write(STDOUT_FILENO, "Error connectant a Gotham\n", 27);
        return;
    }
    establir_connexio_gotham(sock_fd, username, config->ip, config->port);
    connected_to_gotham = 1;
}
/**
 * Llista els fitxers d'un directori segons les extensions donades.
 * @param user_dir El camí del directori.
 * @param media_types Les extensions a cercar.
 * @param count El nombre d'extensions.
 */
void gestionar_comanda_list(const char *user_dir, const char **media_types, size_t count) {
    DIR *dir = opendir(user_dir);
    if (!dir) {
        perror("Error obrint el directori");
        return;
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_REG) { // Només fitxers regulars
            const char *file_name = entry->d_name;
            for (size_t i = 0; i < count; i++) {
                const char *ext = media_types[i];
                size_t len_file = strlen(file_name);
                size_t len_ext = strlen(ext);
                if (len_file > len_ext && strcmp(file_name + len_file - len_ext, ext) == 0) {
                    // Mostra el fitxer si coincideix amb una extensió
                    write(STDOUT_FILENO, file_name, strlen(file_name));
                    write(STDOUT_FILENO, "\n", 1);
                    break;
                }
            }
        }
    }

    closedir(dir);
}

/**
 * Envia el fitxer al worker.
 * @param socket_fd Descriptor del socket connectat al worker.
 * @param file_name Nom del fitxer a enviar.
 * @param file_size Mida del fitxer en bytes.
 * @param md5sum MD5SUM del fitxer per verificar la integritat.
 * @param factor Factor de distorsió.
 * @return 0 si l'enviament és correcte, -1 si hi ha un error.
 */
int enviar_fitxer_worker(int socket_fd, const char *file_name, uint32_t file_size, const char *md5sum, int factor) {
    Trama trama;
    char data[245];
    snprintf(data, sizeof(data), "%s&%u&%s&%d", file_name, file_size, md5sum, factor);
    inicialitzar_trama(&trama, 0x03, data);
    char debug_msg[128];
    snprintf(debug_msg, sizeof(debug_msg), "Enviant fitxer: %s (Mida: %u bytes)\n", file_name, file_size);
    write(STDOUT_FILENO, debug_msg, strlen(debug_msg));

    if (write(socket_fd, &trama, sizeof(trama)) != sizeof(trama)) {
        write(STDOUT_FILENO, "Error enviant la informació del fitxer al worker\n", 48);
        return -1;
    }

    int file_fd = open(file_name, O_RDONLY);
    if (file_fd < 0) {
        perror("Error obrint el fitxer");
        return -1;
    }

    char buffer[256];
    ssize_t bytes_read;
    while ((bytes_read = read(file_fd, buffer, sizeof(buffer))) > 0) {
        trama.type = 0x05;
        trama.data_length = bytes_read;
        memcpy(trama.data, buffer, bytes_read);
        if (write(socket_fd, &trama, sizeof(trama)) != sizeof(trama)) {
            write(STDOUT_FILENO, "Error enviant les dades del fitxer al worker\n", 45);
            close(file_fd);
            return -1;
        }
    }

    if (bytes_read < 0) {
        perror("Error llegint el fitxer");
        close(file_fd);
        return -1;
    }

    close(file_fd);
    return 0;
}


/**
 * Rep el fitxer distorsionat del worker.
 * @param socket_fd Descriptor del socket connectat al worker.
 * @param output_file Nom del fitxer on es desarà la sortida.
 * @return 0 si es rep correctament, -1 si hi ha un error.
 */
int rebre_fitxer_worker(int socket_fd, const char *output_file) {
    Trama trama;
    char debug_msg[32];
    snprintf(debug_msg, sizeof(debug_msg), "Rebent fitxer distorsionat: %s\n", output_file);
    write(STDOUT_FILENO, debug_msg, strlen(debug_msg));

    int output_fd = open(output_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (output_fd < 0) {
        perror("Error creant el fitxer de sortida");
        return -1;
    }

    while (read(socket_fd, &trama, sizeof(trama)) == sizeof(trama)) {
        if (trama.type == 0x05) { // Dades del fitxer
            if (write(output_fd, trama.data, trama.data_length) != trama.data_length) {
                write(STDOUT_FILENO, "Error escrivint el fitxer distorsionat\n", 38);
                close(output_fd);
                return -1;
            }
        } else if (trama.type == 0x06) { // MD5SUM OK/KO
            if (strcmp(trama.data, "CHECK_OK") == 0) {
                write(STDOUT_FILENO, "Fitxer distorsionat rebut correctament\n", 39);
            } else {
                write(STDOUT_FILENO, "Error: MD5SUM incorrecte\n", 26);
                close(output_fd);
                return -1;
            }
            break;
        }
    }

    if (close(output_fd) < 0) {
        perror("Error tancant el fitxer de sortida");
        return -1;
    }
    return 0;
}

/**
 * Gestiona la distorsió d'un fitxer amb el worker.
 * @param worker_ip IP del worker assignat.
 * @param worker_port Port del worker assignat.
 * @param file_name Nom del fitxer a distorsionar.
 * @param factor Factor de distorsió.
 * @return 0 si la distorsió és correcta, -1 si hi ha un error.
 */
int gestionar_distorsio_worker(const char *worker_ip, int worker_port, const char *file_name, int factor) {
    write(STDOUT_FILENO, "Connectant amb el worker: ", 27);
    write(STDOUT_FILENO, worker_ip, strlen(worker_ip));
    write(STDOUT_FILENO, "\n", 1);
    int worker_fd = connectar_a_server(worker_ip, worker_port);
    
    if (worker_fd < 0) {
        write(STDOUT_FILENO, "Error connectant amb el worker\n", 31);
        return -1;
    }
    

    // Calcular mida i MD5SUM del fitxer
    uint32_t file_size;
    char md5sum[33]; // 32 caràcters + 1 per al null terminador
    if (calcular_md5(file_name, md5sum, &file_size) < 0) {
        write(STDOUT_FILENO, "Error calculant MD5SUM\n", 23);
        close(worker_fd);
        return -1;
    }

    // Enviar fitxer al worker
    if (enviar_fitxer_worker(worker_fd, file_name, file_size, md5sum, factor) < 0) {
        close(worker_fd);
        return -1;
    }

    // Rebre fitxer distorsionat
    char output_file[256];
    snprintf(output_file, sizeof(output_file), "distorted_%s", file_name);
    if (rebre_fitxer_worker(worker_fd, output_file) < 0) {
        close(worker_fd);
        return -1;
    }

    close(worker_fd);
    return 0;
}

/**
 * Envia una petició de distorsió a Gotham.
 * @param socket_fd Descriptor del socket connectat a Gotham.
 * @param media_type Tipus de media (per exemple: "media", "text").
 * @param file Nom del fitxer a distorsionar.
 * @return 0 si la petició s'envia correctament, -1 si hi ha un error.
 */
int enviar_peticio_distorsio(int socket_fd, const char *media_type, const char *file, int factor) {
    if (!media_type || !file) {
        write(STDOUT_FILENO, "Error: Tipus de media o nom de fitxer no vàlid\n", 47);
        return -1;
    }

    Trama trama;
    char data[245];
    snprintf(data, sizeof(data), "%s&%s", media_type, file);
    inicialitzar_trama(&trama, 0x10, data);

    if (write(socket_fd, &trama, sizeof(trama)) != sizeof(trama)) {
        write(STDOUT_FILENO, "Error enviant la petició de distorsió\n", 38);
        return -1;
    }

    Trama resposta;
    if (read(socket_fd, &resposta, sizeof(resposta)) != sizeof(resposta)) {
        write(STDOUT_FILENO, "Error rebent la resposta de Gotham\n", 36);
        return -1;
    }

    if (!validar_trama(&resposta)) {
        write(STDOUT_FILENO, "Resposta de Gotham invàlida\n", 29);
        return -1;
    }

    if (resposta.type == 0x10 && resposta.data_length > 0) {
        if (strcmp(resposta.data, "DISTORT_KO") == 0) {
            write(STDOUT_FILENO, "Error: No hi ha workers disponibles\n", 36);
            return -1;
        } else if (strcmp(resposta.data, "MEDIA_KO") == 0) {
            write(STDOUT_FILENO, "Error: Tipus de media incorrecte\n", 33);
            return -1;
        } else {
            write(STDOUT_FILENO, "Petició enviada correctament. Connexió rebuda.\n", 47);
            char worker_ip[16];
            int worker_port;
            sscanf(resposta.data, "%15[^&]&%d", worker_ip, &worker_port);
            gestionar_distorsio_worker(worker_ip, worker_port, file, factor);
        }
    }

    write(STDOUT_FILENO, "Resposta inesperada de Gotham\n", 31);
    return -1;
}

/**
 * Divideix i delega gestions de comandes en funcions més petites.
 * Gestió de la comanda DISTORT.
 * @param command Comanda completa introduïda per l'usuari.
 */
void gestionar_comanda_distort(char *command) {
    if (!connected_to_gotham) {
        write(STDOUT_FILENO, "No estas connectat a Gotham\n", 29);
        return;
    }

    char *file = strtok(command + 8, " ");
    char *factor_str = strtok(NULL, " ");

    if (file && factor_str) {
        int factor = atoi(factor_str);
        if (factor <= 0) {
            write(STDOUT_FILENO, "Error: Factor invalid\n", 22);
            return;
        }

        enviar_peticio_distorsio(sock_fd, "media", file, factor);
    } else {
        write(STDOUT_FILENO, "ERROR: DISTORT <file.xxx> <factor>\n", 36);
    }
}

/**
 * Gestió principal de comandes introduïdes per l'usuari.
 * @param config Configuració de connexió a Gotham.
 * @param username Nom de l'usuari.
 * @param user_dir Directori de l'usuari.
 */
void gestionar_comandes_fleck(ConfigBase *config, const char *username, const char *user_dir) {
    char *command = NULL;
    size_t len = BUF_INICIAL;

    command = malloc(len);
    if (!command) {
        perror("Error al assignar memoria per command");
        return;
    }

    while (1) {
        write(STDOUT_FILENO, "$ ", 2);
        ssize_t leido = read(STDIN_FILENO, command, len - 1);
        if (leido <= 0) break;

        command[leido] = '\0';
        trim_whitespace(command);

        if (strcasecmp(command, "CONNECT") == 0) {
            gestionar_comanda_connect(config, username);
        } else if (strcasecmp(command, "LIST MEDIA") == 0) {
            const char *extensions[] = {".wav", ".mp3", ".jpg", ".png"};
            gestionar_comanda_list(user_dir, extensions, 4);
        } else if (strcasecmp(command, "LIST TEXT") == 0) {
            const char *extensions[] = {".txt"};
            gestionar_comanda_list(user_dir, extensions, 1);
        } else if (strncmp(command, "DISTORT", 7) == 0) {
            gestionar_comanda_distort(command);
        } else if (strcasecmp(command, "LOGOUT") == 0) {
            if (connected_to_gotham) {
                Trama trama;
                inicialitzar_trama(&trama, 0x07, username);
                write(sock_fd, &trama, sizeof(trama));
                close(sock_fd);
                sock_fd = -1;
                connected_to_gotham = 0;
                write(STDOUT_FILENO, "Desconnectat de Gotham\n", 24);
            } else {
                write(STDOUT_FILENO, "No estas connectat a Gotham\n", 29);
            }
        } else {
            write(STDOUT_FILENO, "ERROR: Comanda no valida\n", 26);
        }
    }

    free(command);
    if (sock_fd >= 0) {
        close(sock_fd);
    }
}

/**
 * Punt d'entrada principal del programa Fleck.
 * @param argc Nombre d'arguments.
 * @param argv Array d'arguments.
 * @return Retorna 0 si l'execució és correcta, 1 en cas d'error.
 */
int main(int argc, char *argv[]) {
    if (argc != 2) {
        write(STDOUT_FILENO, "Es: ./fleck <fitxer_configuracio>\n", 35);
        return 1;
    }

    int config_fd = open(argv[1], O_RDONLY);
    if (config_fd < 0) {
        perror("Error obrint el fitxer de configuració");
        return 1;
    }

    // Declara les estructures per emmagatzemar la configuració
    ConfigBase config;        // Per emmagatzemar IP, port, etc.
    char *username = NULL;    // Per al nom d'usuari
    char *user_dir = NULL;    // Per al directori de l'usuari

    // Analitza el fitxer de configuració
    if (parse_fleck_config(config_fd, &config, &username, &user_dir) < 0) {
        write(STDOUT_FILENO, "Error analitzant el fitxer de configuració\n", 45);
        close(config_fd);
        return 1;
    }

    close(config_fd);

    // Mostra la configuració carregada
    printf("Nom d'usuari: %s\n", username);
    printf("Directori de l'usuari: %s\n", user_dir);
    printf("IP de Gotham: %s\n", config.ip);
    printf("Port de Gotham: %d\n", config.port);

    // Assigna el senyal per Ctrl+C
    signal(SIGINT, ctrlc_handler);

    // Inicialitza la gestió de comandes amb la configuració carregada
    gestionar_comandes_fleck(&config, username, user_dir);

    // Allibera la memòria assignada
    free(username);
    free(user_dir);
    free(config.ip);

    return 0;
}
