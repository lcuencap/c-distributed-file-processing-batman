#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>
#include <signal.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "../Utils/file_utils.h"
#include "../Utils/sys_params.h"
#include "../Utils/trames.h"

// Variables globals
ConfigWorker *workers = NULL; // Llista dinàmica de workers
int num_workers = 0;          // Nombre de workers actius
pthread_mutex_t worker_mutex = PTHREAD_MUTEX_INITIALIZER;

Task *task_queue = NULL;      // Cua de tasques
int task_queue_front = 0, task_queue_rear = 0, task_queue_capacity = 0;
pthread_mutex_t task_queue_mutex = PTHREAD_MUTEX_INITIALIZER;
sem_t task_queue_sem;

int log_pipe_fd[2];
pthread_mutex_t arkham_mutex = PTHREAD_MUTEX_INITIALIZER;

ConfigGotham config;
int server_fd = -1;

/**
 * Logger: registra un esdeveniment al sistema.
 */
void log_event(const char *event) {
    pthread_mutex_lock(&arkham_mutex);
    time_t now = time(NULL);
    char timestamp[64];
    strftime(timestamp, sizeof(timestamp), "[%Y-%m-%d %H:%M:%S]", localtime(&now));

    char log_msg[512];
    snprintf(log_msg, sizeof(log_msg), "%s %s\n", timestamp, event);
    write(log_pipe_fd[1], log_msg, strlen(log_msg));
    pthread_mutex_unlock(&arkham_mutex);
}

/**
 * Afegeix un nou worker a la llista.
 * @param new_worker Configuració del nou worker.
 */
void afegir_worker(ConfigWorker new_worker) {
    pthread_mutex_lock(&worker_mutex);
    ConfigWorker *temp = realloc(workers, (num_workers + 1) * sizeof(ConfigWorker));
    if (!temp) {
        perror("Error redimensionant la llista de workers");
        pthread_mutex_unlock(&worker_mutex);
        return;
    }
    workers = temp;
    workers[num_workers] = new_worker;
    num_workers++;
    log_event("Nou worker afegit a la llista");
    pthread_mutex_unlock(&worker_mutex);
}

/**
 * Elimina un worker de la llista.
 * @param socket_fd Socket del worker a eliminar.
 */
void eliminar_worker(int socket_fd) {
    pthread_mutex_lock(&worker_mutex);
    for (int i = 0; i < num_workers; i++) {
        if (workers[i].base.socket_fd == socket_fd) {
            close(workers[i].base.socket_fd);
            free(workers[i].base.ip);

            for (int j = i; j < num_workers - 1; j++) {
                workers[j] = workers[j + 1];
            }

            num_workers--;
            ConfigWorker *temp = realloc(workers, num_workers * sizeof(ConfigWorker));
            if (temp || num_workers == 0) workers = temp;

            log_event("Worker eliminat de la llista");
            break;
        }
    }
    pthread_mutex_unlock(&worker_mutex);
}


/**
 * Afegeix una tasca a la cua.
 * @param task Tasca a afegir.
 */
void afegir_tasca(Task task) {
    pthread_mutex_lock(&task_queue_mutex);
    task_queue[task_queue_rear] = task;
    task_queue_rear = (task_queue_rear + 1) % task_queue_capacity;
    pthread_mutex_unlock(&task_queue_mutex);
    sem_post(&task_queue_sem);
    log_event("Tasca afegida a la cua");
}

/**
 * Elimina totes les tasques associades a un client (Fleck) que s'ha desconnectat.
 * @param client_socket Descriptor del socket del client desconnectat.
 */
void eliminar_tasques_fleck(int client_socket) {
    pthread_mutex_lock(&task_queue_mutex);

    int new_task_count = 0; // Nombre de tasques no associades al client
    for (int i = task_queue_front; i != task_queue_rear; i = (i + 1) % task_queue_capacity) {
        if (task_queue[i].client_socket != client_socket) {
            task_queue[new_task_count++] = task_queue[i];
        }
    }

    task_queue_rear = new_task_count;
    pthread_mutex_unlock(&task_queue_mutex);

    char msg[128];
    snprintf(msg, sizeof(msg), "Tasques eliminades per client desconnectat (socket: %d)\n", client_socket);
    log_event(msg);
}

/**
 * Redistribueix les tasques d'un worker que ha caigut.
 * @param socket_fd Socket del worker caigut.
 */
void redistribuir_tasques_worker(int socket_fd) {
    pthread_mutex_lock(&task_queue_mutex);
    for (int i = task_queue_front; i != task_queue_rear; i = (i + 1) % task_queue_capacity) {
        if (task_queue[i].worker_socket == socket_fd) {
            afegir_tasca(task_queue[i]);
        }
    }
    pthread_mutex_unlock(&task_queue_mutex);
    eliminar_worker(socket_fd);
    log_event("Tasques redistribuïdes després de la caiguda d'un worker");
}

/**
 * Inicialitza la llista dinàmica de workers.
 */
void inicialitzar_workers() {
    workers = NULL;
    num_workers = 0;
}

/**
 * Inicialitza la cua de tasques.
 */
void inicialitzar_cua_tasques(int capacity) {
    task_queue = calloc(capacity, sizeof(Task));
    if (!task_queue) {
        perror("Error inicialitzant la cua de tasques");
        exit(EXIT_FAILURE);
    }
    task_queue_capacity = capacity;
    sem_init(&task_queue_sem, 0, 0);
}
/**
 * Obté la següent tasca de la cua.
 * @return Tasca següent.
 */
Task obtenir_tasca() {
    sem_wait(&task_queue_sem);
    pthread_mutex_lock(&task_queue_mutex);
    Task task = task_queue[task_queue_front];
    task_queue_front = (task_queue_front + 1) % task_queue_capacity;
    pthread_mutex_unlock(&task_queue_mutex);
    return task;
}
/**
 * Verifica si un socket (Fleck) està desconnectat.
 * @param socket_fd Descriptor del socket del Fleck.
 * @return 1 si està desconnectat, 0 si està actiu.
 */
int verificar_fleck(int socket_fd) {
    char buffer[1];
    int result = recv(socket_fd, buffer, sizeof(buffer), MSG_PEEK | MSG_DONTWAIT);
    if (result == 0 || (result < 0 && errno != EAGAIN && errno != EWOULDBLOCK)) {
        return 1; // Fleck desconnectat
    }
    return 0; // Fleck actiu
}

/**
 * Processa una tasca enviada per un Fleck.
 * Busca un worker disponible, li assigna la tasca, o retorna un error si no n'hi ha.
 * També verifica la connexió del Fleck abans i després de l'assignació.
 * @param task Tasca a processar.
 */

void processar_tasca(Task task) {
    pthread_mutex_lock(&worker_mutex);
    for (int i = 0; i < num_workers; i++) {
        if (workers[i].base.socket_fd != -1 && workers[i].busy == 0 &&
            ((strcmp(task.mediaType, "text") == 0 && workers[i].base.type == ENIGMA) ||
             (strcmp(task.mediaType, "media") == 0 && workers[i].base.type == HARLEY))) {
            workers[i].busy = 1;
            pthread_mutex_unlock(&worker_mutex);

            Trama trama;
            char data[512];
            snprintf(data, sizeof(data), "%s&%s", task.fileName, config.base.ip);
            inicialitzar_trama(&trama, 0x10, data);

            if (write(workers[i].base.socket_fd, &trama, sizeof(trama)) != sizeof(trama)) {
                log_event("Error enviant la tasca al worker. Worker possiblement desconnectat.");
                redistribuir_tasques_worker(workers[i].base.socket_fd);
            } else {
                log_event("Tasca enviada correctament al worker");
                task.worker_socket = workers[i].base.socket_fd; 
            }


            workers[i].busy = 0;
            return;
        }
    }
    pthread_mutex_unlock(&worker_mutex);

    Trama resposta;
    inicialitzar_trama(&resposta, 0x10, "DISTORT_KO");
    if (!verificar_fleck(task.client_socket)) {
        write(task.client_socket, &resposta, sizeof(resposta));
    } else {
        log_event("No s'ha pogut notificar el Fleck perquè està desconnectat.");
        eliminar_tasques_fleck(task.client_socket);
    }
}

/**
 * Inicialitza el logger Arkham.
 */
void inicialitzar_arkham_logger() {
    if (pipe(log_pipe_fd) == -1) {
        perror("Error creant la pipe per Arkham");
        exit(EXIT_FAILURE);
    }
    if (fork() == 0) {
        close(log_pipe_fd[1]);
        int log_fd = open("logs.txt", O_WRONLY | O_CREAT | O_APPEND, 0644);
        if (log_fd < 0) {
            perror("Error obrint logs.txt");
            exit(EXIT_FAILURE);
        }

        char buffer[512];
        while (read(log_pipe_fd[0], buffer, sizeof(buffer)) > 0) {
            write(log_fd, buffer, strlen(buffer));
        }
        close(log_fd);
        close(log_pipe_fd[0]);
        exit(0);
    }
    close(log_pipe_fd[0]);
}

int verificar_worker(int socket_fd) {
    char buffer[1];
    int result = recv(socket_fd, buffer, sizeof(buffer), MSG_PEEK | MSG_DONTWAIT);
    if (result == 0 || (result < 0 && errno != EAGAIN && errno != EWOULDBLOCK)) {
        return 1; // Worker desconnectat
    }
    return 0; // Worker actiu
}

void comprovar_workers() {
    int workers_actius = 0;
    pthread_mutex_lock(&worker_mutex);
    for (int i = 0; i < num_workers; i++) {
        if (verificar_worker(workers[i].base.socket_fd)) {
            log_event("Worker desconnectat detectat");
            redistribuir_tasques_worker(workers[i].base.socket_fd);
        }else {
            workers_actius++;
        }
    }
    pthread_mutex_unlock(&worker_mutex);
    char msg[24];
    snprintf(msg, sizeof(msg), "Workers actius: %d", workers_actius);
    log_event(msg);
}

void *monitor_workers(void *arg) {
    (void)arg;
    while (1) {
        comprovar_workers();
        sleep(2);
    }
    return NULL;
}

/**
 * Escolta connexions entrants i processa segons el tipus de trama rebuda.
 * - TYPE: 0x01 -> Connexió d'un client (Fleck).
 * - TYPE: 0x02 -> Connexió d'un worker.
 * - TYPE: 0x03 -> Petició de distorsió de Fleck.
 * Si hi ha errors o connexions no vàlides, es tanquen.
 */
void listener() {
    struct sockaddr_in address;
    socklen_t addrlen = sizeof(address);
    char *msg = NULL;

    // Crear socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        const char *error_msg = "Error creant el socket\n";
        write(STDERR_FILENO, error_msg, strlen(error_msg));
        exit(EXIT_FAILURE);
    }

    // Configurar l'adreça
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = inet_addr(config.base.ip);
    address.sin_port = htons(config.base.port);

    // Bind
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        size_t len = snprintf(NULL, 0, "Error en el bind a IP %s, Port %d\n", config.base.ip, config.base.port) + 1;
        msg = malloc(len);
        if (msg) {
            snprintf(msg, len, "Error en el bind a IP %s, Port %d\n", config.base.ip, config.base.port);
            write(STDERR_FILENO, msg, len - 1);
            free(msg);
        }
        exit(EXIT_FAILURE);
    }

    // Listen
    if (listen(server_fd, 10) < 0) {
        const char *error_msg = "Error en el listen\n";
        write(STDERR_FILENO, error_msg, strlen(error_msg));
        exit(EXIT_FAILURE);
    }

    // Log d'inicialització
    size_t init_len = snprintf(NULL, 0, "Servidor Gotham inicialitzat a IP %s, Port %d\n", config.base.ip, config.base.port) + 1;
    msg = malloc(init_len);
    if (msg) {
        snprintf(msg, init_len, "Servidor Gotham inicialitzat a IP %s, Port %d\n", config.base.ip, config.base.port);
        write(STDOUT_FILENO, msg, init_len - 1);
        free(msg);
    }

    // Bucle principal
    while (1) {
        int client_socket = accept(server_fd, (struct sockaddr *)&address, &addrlen);
        if (client_socket < 0) {
            const char *error_msg = "Error en el accept\n";
            write(STDERR_FILENO, error_msg, strlen(error_msg));
            continue;
        }

        size_t conn_len = snprintf(NULL, 0, "Nova connexió des de %s:%d\n",
                                   inet_ntoa(address.sin_addr), ntohs(address.sin_port)) + 1;
        msg = malloc(conn_len);
        if (msg) {
            snprintf(msg, conn_len, "Nova connexió des de %s:%d\n",
                     inet_ntoa(address.sin_addr), ntohs(address.sin_port));
            write(STDOUT_FILENO, msg, conn_len - 1);
            free(msg);
        }

        Trama trama;
        if (read(client_socket, &trama, sizeof(trama)) == sizeof(trama)) {
            size_t trama_len = snprintf(NULL, 0, "Trama rebuda: Type %d, Data: %.200s\n", trama.type, trama.data) + 1;
            msg = malloc(trama_len);
            if (msg) {
                snprintf(msg, trama_len, "Trama rebuda: Type %d, Data: %.200s\n", trama.type, trama.data);
                write(STDOUT_FILENO, msg, trama_len - 1);
                free(msg);
            }

            if (trama.type == 0x01) { // Connexió inicial de Fleck
                log_event("Connexió inicial de Fleck detectada");

                // Enviar resposta a Fleck
                Trama resposta;
                inicialitzar_trama(&resposta, 0x01, ""); // Resposta buida per indicar èxit
                write(client_socket, &resposta, sizeof(resposta));
                log_event("Resposta enviada a Fleck");
            } else if (trama.type == 0x02) { // Connexió d'un worker
                ConfigWorker worker = {
                    .base.socket_fd = client_socket,
                    .base.ip = strdup(config.base.ip),
                    .base.port = config.base.port,
                };
                afegir_worker(worker);

                const char *worker_msg = "Worker registrat\n";
                write(STDOUT_FILENO, worker_msg, strlen(worker_msg));
            } else if (trama.type == 0x03) { // Petició d'un client
                if (!verificar_fleck(client_socket)) {
                    Task new_task = {
                        .client_socket = client_socket,
                        .worker_socket = -1
                    };
                    strncpy(new_task.mediaType, trama.data, sizeof(new_task.mediaType));
                    strncpy(new_task.fileName, trama.data + strlen(new_task.mediaType) + 1, sizeof(new_task.fileName));
                    afegir_tasca(new_task);

                    const char *task_msg = "Tasca de Fleck afegida\n";
                    write(STDOUT_FILENO, task_msg, strlen(task_msg));
                } else {
                    const char *disconnect_msg = "Fleck desconnectat abans d'afegir la tasca. Eliminant connexió.\n";
                    write(STDOUT_FILENO, disconnect_msg, strlen(disconnect_msg));
                    eliminar_tasques_fleck(client_socket);
                    close(client_socket);
                }
            } else {
                const char *invalid_msg = "Connexió no vàlida detectada. Tancant socket.\n";
                write(STDOUT_FILENO, invalid_msg, strlen(invalid_msg));
                close(client_socket);
            }
        } else {
            const char *error_msg = "Error en la lectura de la trama. Eliminant client.\n";
            write(STDOUT_FILENO, error_msg, strlen(error_msg));
            eliminar_tasques_fleck(client_socket);
            close(client_socket);
        }
    }
}



/**
 * Processa les tasques de la cua en un fil separat.
 */
void *task_processor(void *arg) {
    (void)arg;
    while (1) {
        Task task = obtenir_tasca();
        processar_tasca(task);
    }
    return NULL;
}
/**
 * Gestió del senyal SIGINT: tancament ordenat.
 */
void sigint_handler(int sig) {
    (void) sig;
    log_event("Tancant Gotham...");

    // Notificar workers
    for (int i = 0; i < num_workers; i++) {
        if (workers[i].base.socket_fd != -1) {
            Trama notify_trama;
            inicialitzar_trama(&notify_trama, 0x07, "GOTHAM_DOWN");
            if (write(workers[i].base.socket_fd, &notify_trama, sizeof(notify_trama)) != sizeof(notify_trama)) {
                log_event("Error enviant notificació de tancament al worker");
            }
        }
    }

    // Notificar clients amb tasques pendents
    pthread_mutex_lock(&task_queue_mutex);
    for (int i = task_queue_front; i != task_queue_rear; i = (i + 1) % task_queue_capacity) {
        int client_socket = task_queue[i].client_socket;
        Trama notify_trama;
        inicialitzar_trama(&notify_trama, 0x07, "TASK_ABORTED");
        write(client_socket, &notify_trama, sizeof(notify_trama));
        close(client_socket);
    }
    pthread_mutex_unlock(&task_queue_mutex);

    // Alliberar recursos
    free(workers);
    free(task_queue);
    sem_destroy(&task_queue_sem);
    close(server_fd);
    log_event("Gotham tancat correctament");
    exit(0);
}

/**
 * Mostra la configuració carregada per pantalla.
 * @param config Configuració de Gotham.
 */
void mostrar_config() {
    char buffer[200];
    int len = snprintf(buffer, sizeof(buffer),
        "Configuració de Gotham carregada:\n"
        "  IP Base: %s\n"
        "  Port Base: %d\n"
        "  IP Workers: %s\n"
        "  Port Workers: %d\n",
        config.base.ip, config.base.port, config.worker_ip, config.worker_port);

    write(STDOUT_FILENO, buffer, len);
}


/**
 * Funció principal.
 */
int main(int argc, char *argv[]) {
    if (argc != 2) {
        write(STDOUT_FILENO, "Us: ./gotham <fitxer_configuracio>\n", 36);
        return 1;
    }

    int config_fd = open(argv[1], O_RDONLY);
    if (config_fd < 0 || parse_gotham_config(config_fd, &config) < 0) {
        perror("Error carregant la configuració de Gotham");
        return 1;
    }
    close(config_fd);

    mostrar_config();

    inicialitzar_workers();
    inicialitzar_cua_tasques(20);
    inicialitzar_arkham_logger();

    pthread_t task_thread;
    if (pthread_create(&task_thread, NULL, task_processor, NULL) != 0) {
        perror("Error creant el fil del processador de tasques");
        exit(EXIT_FAILURE);
    }    
    pthread_t monitor_thread;
    if (pthread_create(&monitor_thread, NULL, monitor_workers, NULL) != 0) {
        log_event("Error: No s'ha pogut crear el fil de monitoratge de workers.");
        exit(EXIT_FAILURE);
    }
    
    signal(SIGINT, sigint_handler);
    listener();

    return 0;
}