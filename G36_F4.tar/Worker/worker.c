#include "worker.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <arpa/inet.h>

/**
 * Gestiona la desconnexió del worker de Gotham.
 * @param socket_fd Descriptor del socket connectat a Gotham.
 * @param workerType Tipus de worker (e.g., "Media" o "Text").
 */
void gestionar_desconnexio_gotham(int socket_fd, const char *workerType) {
    if (socket_fd < 0 || !workerType) {
        const char *msg = "Error: Paràmetres invàlids a gestionar_desconnexio_gotham\n";
        write(STDOUT_FILENO, msg, strlen(msg));
        return;
    }

    Trama trama;
    inicialitzar_trama(&trama, 0x07, workerType);

    if (write(socket_fd, &trama, sizeof(trama)) != sizeof(trama)) {
        perror("Error enviant la trama de desconnexió a Gotham");
    } else {
        const char *msg = "Trama de desconnexió enviada a Gotham\n";
        write(STDOUT_FILENO, msg, strlen(msg));
    }

    if (close(socket_fd) < 0) {
        perror("Error tancant el socket");
    } else {
        const char *msg = "Socket tancat correctament\n";
        write(STDOUT_FILENO, msg, strlen(msg));
    }
}

/**
 * Inicialitza la connexió amb Gotham.
 * @param workerType Tipus de worker (e.g., "Media").
 * @param ip Adreça IP de Gotham.
 * @param port Port de Gotham.
 */
void inicialitzar_connexio_gotham(const char *workerType, const char *ip, int port) {
    Trama trama;
    char data[245];
    snprintf(data, sizeof(data), "%s&%s&%d", workerType, ip, port);
    inicialitzar_trama(&trama, 0x02, data);

    int socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (socket_fd < 0) {
        perror("Error creant el socket");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in gotham_addr;
    gotham_addr.sin_family = AF_INET;
    gotham_addr.sin_port = htons(port);
    inet_pton(AF_INET, ip, &gotham_addr.sin_addr);

    if (connect(socket_fd, (struct sockaddr *)&gotham_addr, sizeof(gotham_addr)) < 0) {
        perror("Error connectant a Gotham");
        close(socket_fd);
        exit(EXIT_FAILURE);
    }

    write(socket_fd, &trama, sizeof(trama));

    Trama resposta;
    if (read(socket_fd, &resposta, sizeof(resposta)) != sizeof(resposta)) {
        const char *msg = "Error rebent resposta de Gotham\n";
        write(STDOUT_FILENO, msg, strlen(msg));
        close(socket_fd);
        exit(EXIT_FAILURE);
    }

    if (!validar_trama(&resposta)) {
        const char *msg = "Resposta de Gotham invàlida\n";
        write(STDOUT_FILENO, msg, strlen(msg));
        close(socket_fd);
        exit(EXIT_FAILURE);
    }

    if (resposta.type == 0x02 && resposta.data_length == 0) {
        const char *msg = "Connexió establerta amb Gotham\n";
        write(STDOUT_FILENO, msg, strlen(msg));
    } else {
        size_t msg_size = strlen("Connexió rebutjada per Gotham: ") + strlen(resposta.data) + 2;
        char *msg = malloc(msg_size);
        if (!msg) {
            perror("Error al·loco memòria per al missatge");
            close(socket_fd);
            exit(EXIT_FAILURE);
        }
        snprintf(msg, msg_size, "Connexió rebutjada per Gotham: %s\n", resposta.data);
        write(STDOUT_FILENO, msg, strlen(msg));
        free(msg);
        close(socket_fd);
        exit(EXIT_FAILURE);
    }

    close(socket_fd);
}

/**
 * Valida una trama per assegurar-se que el checksum és correcte.
 * @param trama Punter a la trama a validar.
 * @return 1 si és vàlida, 0 altrament.
 */
int validar_checksum(Trama *trama) {
    uint16_t checksum_calculat = generate_checksum((const uint8_t *)trama, TRAMA_SIZE - 2);
    return checksum_calculat == trama->checksum;
}


/**
 * Envia el fitxer processat al client.
 * @param client_socket Descriptor del socket del client.
 * @param output_path Ruta del fitxer processat.
 * @param file_size Mida del fitxer en bytes.
 * @param checksum Checksum del fitxer per verificar la integritat.
 */
void enviar_fitxer_processat(int client_socket, const char *output_path, uint32_t file_size, const char *checksum) {
    if (!output_path || !checksum) {
        write(STDOUT_FILENO, "Error: Paràmetres invàlids\n", 26);
        return;
    }

    int fd = open(output_path, O_RDONLY);
    if (fd < 0) {
        perror("Error obrint el fitxer processat");
        Trama error_trama;
        inicialitzar_trama(&error_trama, 0x06, "ERROR: No es pot obrir el fitxer processat");
        write(client_socket, &error_trama, sizeof(error_trama));
        return;
    }

    char calculated_checksum[MD5SUM_LENGTH];
    uint32_t dummy_size;
    if (calcular_md5(output_path, calculated_checksum, &dummy_size) < 0 || strcmp(calculated_checksum, checksum) != 0) {
        Trama check_ko_trama;
        inicialitzar_trama(&check_ko_trama, 0x06, "CHECK_KO");
        write(client_socket, &check_ko_trama, sizeof(check_ko_trama));
        close(fd);
        return;
    }

    Trama info_trama;
    char data[245];
    snprintf(data, sizeof(data), "%u&%s", file_size, checksum);
    inicialitzar_trama(&info_trama, 0x04, data);
    if (write(client_socket, &info_trama, sizeof(info_trama)) != sizeof(info_trama)) {
        write(STDOUT_FILENO, "Error enviant informació del fitxer\n", 36);
        close(fd);
        return;
    }

    char buffer[245];
    ssize_t bytes_read;
    Trama data_trama;
    while ((bytes_read = read(fd, buffer, sizeof(buffer))) > 0) {
        inicialitzar_trama(&data_trama, 0x05, "");
        memcpy(data_trama.data, buffer, bytes_read);
        data_trama.data_length = bytes_read;

        if (write(client_socket, &data_trama, sizeof(data_trama)) != sizeof(data_trama)) {
            write(STDOUT_FILENO, "Error enviant dades del fitxer\n", 32);
            close(fd);
            return;
        }
    }

    if (bytes_read < 0) {
        perror("Error llegint el fitxer processat");
        close(fd);
        return;
    }

    Trama final_trama;
    inicialitzar_trama(&final_trama, 0x06, "CHECK_OK");
    write(client_socket, &final_trama, sizeof(final_trama));

    close(fd);
}

/**
 * Analitza les dades d'una trama i extreu la mida del fitxer i el checksum.
 * @param data Cadena de dades rebuda a la trama.
 * @param file_size Punter per emmagatzemar la mida del fitxer.
 * @param checksum Punter per emmagatzemar el checksum del fitxer.
 */
void parse_trama_data(const char *data, uint32_t *file_size, char *checksum) {
    if (!data || !file_size || !checksum) {
        write(STDERR_FILENO, "Error: Paràmetres invàlids a parse_trama_data\n", 46);
        return;
    }

    // Troba la posició del separador '&' per dividir file_size i checksum
    const char *separator = strchr(data, '&');
    if (!separator) {
        write(STDERR_FILENO, "Error: Format de dades de trama invàlid\n", 40);
        return;
    }

    // Extreu la mida del fitxer
    char size_buffer[16] = {0};
    strncpy(size_buffer, data, separator - data);
    *file_size = (uint32_t)strtoul(size_buffer, NULL, 10);

    // Extreu el checksum
    strncpy(checksum, separator + 1, 32); // Checksum ha de ser de 32 bytes
    checksum[32] = '\0'; // Assegura que el checksum és una cadena amb terminador NULL
}

/**
 * Gestiona la recepció de fitxers de Fleck.
 * @param client_socket Descriptor del socket del client.
 * @param file_path Ruta del fitxer a guardar.
 * @param file_size Mida del fitxer.
 * @param checksum Checksum esperat del fitxer.
 * @return 0 si la recepció és correcta, -1 en cas contrari.
 */
int gestionar_recepcio_fitxer(int client_socket, char *file_path, uint32_t *file_size, char *checksum) {
    Trama trama;
    if (read(client_socket, &trama, sizeof(trama)) != sizeof(trama)) {
        return -1;
    }

    if (!validar_trama(&trama) || trama.type != 0x04) {
        return -1;
    }

    parse_trama_data(trama.data, file_size, checksum);

    int fd = open(file_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) {
        return -1;
    }

    while (1) {
        if (read(client_socket, &trama, sizeof(trama)) != sizeof(trama)) break;

        if (!validar_trama(&trama) || trama.type != 0x05) {
            close(fd);
            unlink(file_path);
            return -1;
        }

        if (write(fd, trama.data, trama.data_length) < 0) {
            close(fd);
            unlink(file_path);
            return -1;
        }
    }

    close(fd);
    return 0;
}


