#include "../worker.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <ctype.h>

// Variables globals
static Task *task_list = NULL;   // Llista de tasques pendents
static int task_count = 0;       // Nombre de tasques pendents
static pthread_mutex_t task_mutex = PTHREAD_MUTEX_INITIALIZER;
static ConfigWorker config;      // Configuració d'Enigma

/**
 * @brief Processa un fitxer de text eliminant paraules més curtes que un llindar.
 * @param file_name Nom del fitxer a processar.
 * @param threshold Llindar mínim de longitud de paraules.
 * @return Retorna 0 si el processament és correcte, -1 en cas d'error.
 */
int processText(const char *file_name, size_t threshold) {
    if (!file_name || threshold <= 0) {
        return -1;
    }

    int input_fd = open(file_name, O_RDONLY);
    if (input_fd < 0) {
        perror("Error obrint el fitxer d'entrada");
        return -1;
    }

    char output_file_name[256];
    snprintf(output_file_name, sizeof(output_file_name), "distorted_%s", file_name);

    int output_fd = open(output_file_name, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (output_fd < 0) {
        perror("Error obrint el fitxer de sortida");
        close(input_fd);
        return -1;
    }

    char buffer[256], word[256];
    ssize_t bytes_read;
    size_t word_len = 0;

    while ((bytes_read = read(input_fd, buffer, sizeof(buffer))) > 0) {
        for (ssize_t i = 0; i < bytes_read; i++) {
            if (isspace(buffer[i])) {
                if (word_len >= threshold) {
                    write(output_fd, word, word_len);
                    write(output_fd, " ", 1);
                }
                word_len = 0;
            } else if (word_len < sizeof(word) - 1) {
                word[word_len++] = buffer[i];
            }
        }
    }

    if (word_len >= threshold) {
        write(output_fd, word, word_len);
        write(output_fd, " ", 1);
    }

    close(input_fd);
    close(output_fd);
    return bytes_read < 0 ? -1 : 0;
}

/**
 * @brief Afegeix una nova tasca a la llista de tasques pendents.
 * @param client_socket Descriptor del socket del client.
 * @param file_name Nom del fitxer associat a la tasca.
 */
void add_task(int client_socket, const char *file_name) {
    pthread_mutex_lock(&task_mutex);
    Task *new_task_list = realloc(task_list, (task_count + 1) * sizeof(Task));
    if (!new_task_list) {
        perror("Error redimensionant la llista de tasques");
        pthread_mutex_unlock(&task_mutex);
        return;
    }
    task_list = new_task_list;
    task_list[task_count].client_socket = client_socket;
    strncpy(task_list[task_count].fileName, file_name, sizeof(task_list[task_count].fileName));
    task_count++;
    pthread_mutex_unlock(&task_mutex);
}

/**
 * @brief Elimina una tasca de la llista de tasques pendents.
 * @param client_socket Descriptor del socket del client associat.
 */
void remove_task(int client_socket) {
    pthread_mutex_lock(&task_mutex);
    for (int i = 0; i < task_count; i++) {
        if (task_list[i].client_socket == client_socket) {
            for (int j = i; j < task_count - 1; j++) {
                task_list[j] = task_list[j + 1];
            }
            task_count--;
            Task *new_task_list = realloc(task_list, task_count * sizeof(Task));
            if (new_task_list || task_count == 0) {
                task_list = new_task_list;
            }
            break;
        }
    }
    pthread_mutex_unlock(&task_mutex);
}

/**
 * @brief Gestiona la recepció i processament d'una tasca.
 * @param arg Punter al socket del client.
 */
void *handle_task(void *arg) {
    int client_socket = *(int *)arg;
    free(arg);

    Trama request_trama;
    if (read(client_socket, &request_trama, sizeof(request_trama)) <= 0 || request_trama.type != 0x03) {
        close(client_socket);
        return NULL;
    }

    char file_name[256];
    uint32_t file_size;
    char received_checksum[33];
    sscanf(request_trama.data, "%[^&]&%u&%s", file_name, &file_size, received_checksum);

    uint32_t calculated_size;
    char calculated_checksum[33];
    if (gestionar_recepcio_fitxer(client_socket, file_name, &calculated_size, calculated_checksum) < 0 ||
        strcmp(received_checksum, calculated_checksum) != 0) {
        Trama error_trama;
        inicialitzar_trama(&error_trama, 0x06, "CHECK_KO");
        write(client_socket, &error_trama, sizeof(error_trama));
        close(client_socket);
        return NULL;
    }

    Trama success_trama;
    inicialitzar_trama(&success_trama, 0x06, "CHECK_OK");
    write(client_socket, &success_trama, sizeof(success_trama));

    if (processText(file_name, 5) < 0 || calcular_md5(file_name, calculated_checksum, &calculated_size) < 0) {
        unlink(file_name);
        return NULL;
    }

    enviar_fitxer_processat(client_socket, file_name, calculated_size, calculated_checksum);
    remove_task(client_socket);
    
    return NULL;
}

/**
 * Escolta connexions entrants.
 */
void listener_enigma() {
    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("Error creant el socket");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in address = {
        .sin_family = AF_INET,
        .sin_addr.s_addr = INADDR_ANY,
        .sin_port = htons(config.base.port),
    };

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Error fent bind");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 10) < 0) {
        perror("Error fent listen");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    while (1) {
        int client_socket = accept(server_fd, NULL, NULL);
        if (client_socket < 0) continue;

        pthread_t thread_id;
        int *client_socket_ptr = malloc(sizeof(int));
        *client_socket_ptr = client_socket;
        pthread_create(&thread_id, NULL, handle_task, client_socket_ptr);
        pthread_detach(thread_id);
    }

    close(server_fd);
}

/**
 * @brief Gestió del senyal SIGINT per finalitzar el worker.
 * @param sig Senyal rebut.
 */
void gestionar_signal_interrupt(int sig) {
    (void) sig;

    gestionar_desconnexio_gotham(config.base.socket_fd, "Text");

    pthread_mutex_lock(&task_mutex);
    for (int i = 0; i < task_count; i++) {
        close(task_list[i].client_socket);
    }
    free(task_list);
    task_list = NULL;
    task_count = 0;
    pthread_mutex_unlock(&task_mutex);

    close(config.base.socket_fd);
    free(config.work_dir);
    exit(0);
}

/**
 * @brief Punt d'entrada principal del worker Enigma.
 * @param argc Nombre d'arguments.
 * @param argv Array d'arguments.
 * @return Retorna 0 si s'executa correctament, 1 en cas d'error.
 */
int main(int argc, char *argv[]) {
    if (argc != 2) {
        write(STDOUT_FILENO, "Us: ./enigma <fitxer_configuracio>\n", 36);
        return 1;
    }

    int config_fd = open(argv[1], O_RDONLY);
    if (config_fd < 0 || parse_worker_config(config_fd, &config) < 0) {
        perror("Error carregant la configuració");
        return 1;
    }
    close(config_fd);

    inicialitzar_connexio_gotham("Text", config.base.ip, config.base.port);
    signal(SIGINT, gestionar_signal_interrupt);
    listener_enigma();

    return 0;
}