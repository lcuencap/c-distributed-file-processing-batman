#ifndef WORKER_H
#define WORKER_H

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <errno.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <signal.h>
#include "../Utils/trames.h"
#include "../Utils/sys_params.h"
#include "../Utils/file_utils.h"

// Inicialitza la connexió amb Gotham
void inicialitzar_connexio_gotham(const char *workerType, const char *ip, int port);

void parse_trama_data(const char *data, uint32_t *file_size, char *checksum);

// Gestiona la recepció de fitxers de Fleck
int gestionar_recepcio_fitxer(int client_socket, char *file_path, uint32_t *file_size, char *checksum);

// Envia el fitxer processat a Fleck
void enviar_fitxer_processat(int client_socket, const char *output_path, uint32_t file_size, const char *checksum);

// Gestiona la desconnexió del worker
void gestionar_desconnexio_gotham(int socket_fd, const char *workerType);

#endif // WORKER_H
