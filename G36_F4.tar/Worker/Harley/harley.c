#include "../worker.h"
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <fcntl.h>
#include "../../Utils/so_compression.h"

// Variables globals
static Task *task_list = NULL;  // Llista de tasques pendents
static int task_count = 0;      // Nombre de tasques pendents
static pthread_mutex_t task_mutex = PTHREAD_MUTEX_INITIALIZER;  // Mutex per gestionar les tasques
static ConfigWorker config;     // Configuració de Harley

/**
 * @brief Afegeix una nova tasca a la llista de tasques pendents.
 * @param client_socket Descriptor del socket del client.
 * @param file_name Nom del fitxer associat a la tasca.
 */
void add_task(int client_socket, const char *file_name) {
    pthread_mutex_lock(&task_mutex);
    Task *new_task_list = realloc(task_list, (task_count + 1) * sizeof(Task));
    if (!new_task_list) {
        write(STDERR_FILENO, "Error redimensionant la llista de tasques\n", 42);
        pthread_mutex_unlock(&task_mutex);
        return;
    }
    task_list = new_task_list;
    task_list[task_count].client_socket = client_socket;
    strncpy(task_list[task_count].fileName, file_name, sizeof(task_list[task_count].fileName));
    task_count++;
    pthread_mutex_unlock(&task_mutex);
}

/**
 * @brief Elimina una tasca de la llista de tasques pendents.
 * @param client_socket Descriptor del socket del client.
 */
void remove_task(int client_socket) {
    pthread_mutex_lock(&task_mutex);
    for (int i = 0; i < task_count; i++) {
        if (task_list[i].client_socket == client_socket) {
            for (int j = i; j < task_count - 1; j++) {
                task_list[j] = task_list[j + 1];
            }
            task_count--;
            Task *new_task_list = realloc(task_list, task_count * sizeof(Task));
            if (new_task_list || task_count == 0) {
                task_list = new_task_list;
            }
            break;
        }
    }
    pthread_mutex_unlock(&task_mutex);
}

/**
 * @brief Gestiona la recepció i processament d'una petició de distorsió.
 * @param client_socket Descriptor del socket del client.
 */
void handle_distortion_request(int client_socket) {
    Trama request_trama;
    char file_name[256];
    char received_checksum[33];
    uint32_t file_size;
    int distortion_factor;

    if (read(client_socket, &request_trama, sizeof(request_trama)) <= 0 || request_trama.type != 0x03) {
        close(client_socket);
        return;
    }

    char *separator1 = strchr(request_trama.data, '&');
    char *separator2 = strchr(separator1 + 1, '&');
    char *separator3 = strchr(separator2 + 1, '&');
    if (!separator1 || !separator2 || !separator3) {
        Trama error_trama;
        inicialitzar_trama(&error_trama, 0x06, "ERROR: Dades invàlides.");
        write(client_socket, &error_trama, sizeof(error_trama));
        close(client_socket);
        return;
    }

    size_t filename_len = separator1 - request_trama.data;
    strncpy(file_name, request_trama.data, filename_len);
    file_name[filename_len] = '\0';

    file_size = (uint32_t)atoi(separator1 + 1);
    strncpy(received_checksum, separator2 + 1, separator3 - separator2 - 1);
    received_checksum[separator3 - separator2 - 1] = '\0';
    distortion_factor = atoi(separator3 + 1);

    if (gestionar_recepcio_fitxer(client_socket, file_name, &file_size, received_checksum) < 0) {
        Trama error_trama;
        inicialitzar_trama(&error_trama, 0x06, "CHECK_KO");
        write(client_socket, &error_trama, sizeof(error_trama));
        close(client_socket);
        return;
    }

    char calculated_checksum[33];
    uint32_t dummy_size;

    if (calcular_md5(file_name, calculated_checksum, &dummy_size) < 0 || strcmp(received_checksum, calculated_checksum) != 0) {
        Trama error_trama;
        inicialitzar_trama(&error_trama, 0x06, "CHECK_KO");
        write(client_socket, &error_trama, sizeof(error_trama));
        unlink(file_name);
        close(client_socket);
        return;
    }

    int result = strstr(file_name, ".wav") ? 
                 SO_compressAudio(file_name, distortion_factor) :
                 SO_compressImage(file_name, distortion_factor);

    if (result != NO_ERROR) {
        Trama error_trama;
        inicialitzar_trama(&error_trama, 0x06, "ERROR: Fallada al comprimir.");
        write(client_socket, &error_trama, sizeof(error_trama));
        unlink(file_name);
        close(client_socket);
        return;
    }

    enviar_fitxer_processat(client_socket, file_name, file_size, calculated_checksum);
    remove_task(client_socket);
}

/**
 * @brief Processa la connexió d'un client.
 * @param arg Punter al socket del client.
 * @return NULL.
 */
void *handle_client_connection(void *arg) {
    int client_socket = *(int *)arg;
    free(arg);

    Trama initial_trama;
    if (read(client_socket, &initial_trama, sizeof(initial_trama)) <= 0) {
        close(client_socket);
        return NULL;
    }

    switch (initial_trama.type) {
        case 0x03:
            handle_distortion_request(client_socket);
            break;
        default: {
            Trama error_trama;
            inicialitzar_trama(&error_trama, 0x09, "ERROR: Comanda desconeguda.");
            write(client_socket, &error_trama, sizeof(error_trama));
            break;
        }
    }

    close(client_socket);
    return NULL;
}

/**
 * @brief Escolta connexions entrants.
 */
void listener_harley() {
    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) exit(EXIT_FAILURE);

    struct sockaddr_in address = {
        .sin_family = AF_INET,
        .sin_addr.s_addr = INADDR_ANY,
        .sin_port = htons(config.base.port),
    };

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 10) < 0) {
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    while (1) {
        int client_socket = accept(server_fd, NULL, NULL);
        if (client_socket < 0) continue;

        pthread_t thread_id;
        int *client_socket_ptr = malloc(sizeof(int));
        *client_socket_ptr = client_socket;
        pthread_create(&thread_id, NULL, handle_client_connection, client_socket_ptr);
        pthread_detach(thread_id);
    }

    close(server_fd);
}

/**
 * @brief Gestiona el senyal SIGINT.
 * @param sig Senyal rebut.
 */
void handle_sigint(int sig) {
    (void)sig;
    gestionar_desconnexio_gotham(config.base.socket_fd, "Media");

    pthread_mutex_lock(&task_mutex);
    for (int i = 0; i < task_count; i++) {
        close(task_list[i].client_socket);
    }
    free(task_list);
    task_list = NULL;
    task_count = 0;
    pthread_mutex_unlock(&task_mutex);

    close(config.base.socket_fd);
    free(config.work_dir);
    exit(0);
}

/**
 * @brief Punt d'entrada principal.
 * @param argc Nombre d'arguments.
 * @param argv Array d'arguments.
 * @return Retorna 0 si s'executa correctament, 1 en cas d'error.
 */
int main(int argc, char *argv[]) {
    if (argc != 2) {
        write(STDOUT_FILENO, "Us: ./harley <fitxer_configuracio>\n", 36);
        return 1;
    }

    int config_fd = open(argv[1], O_RDONLY);
    if (config_fd < 0 || parse_worker_config(config_fd, &config) < 0) return 1;
    close(config_fd);

    inicialitzar_connexio_gotham("Media", config.base.ip, config.base.port);
    signal(SIGINT, handle_sigint);
    listener_harley();
    return 0;
}
