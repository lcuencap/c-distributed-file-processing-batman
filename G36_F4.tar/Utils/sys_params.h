#ifndef _SYS_PARAMS_H_
#define _SYS_PARAMS_H_

#define MD5SUM_LENGTH 33
#define SO_NO_ERROR 0
#define SO_ERROR_UNSUPPORTED_FORMAT 1

typedef struct {
    char mediaType[16];
    char fileName[256];
    int client_socket;
    int worker_socket; 
} Task;

typedef enum {
    GOTHAM,
    ENIGMA,
    HARLEY,
    FLECK
} InstanceType;

typedef struct {
    InstanceType type;    
    char *ip;             
    int port;             
    int socket_fd;        
} ConfigBase;

typedef struct {
    ConfigBase base;      
    char *worker_ip;      // IP workers (Harley/Enigma)
    int worker_port;      // Port workers
} ConfigGotham;

typedef struct {
    ConfigBase base;      
    char *work_dir;       // Directori del worker
    int busy;             // 0 = disponible, 1 = ocupat
} ConfigWorker;


#endif

